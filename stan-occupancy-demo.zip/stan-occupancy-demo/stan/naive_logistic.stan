// Naive comparison model: logistic regression of "species ever recorded
// at the site" on occupancy covariates. It ignores imperfect detection,
// so it estimates P(detected at least once), not P(occupied).

data {
  int<lower=1> M;
  array[M] int<lower=0, upper=1> y_any;  // 1 if detected on any visit
  int<lower=1> K_psi;
  matrix[M, K_psi] X_psi;
}

parameters {
  vector[K_psi] beta;
}

model {
  beta ~ normal(0, 1.5);
  y_any ~ bernoulli_logit(X_psi * beta);
}

generated quantities {
  real psi_naive = mean(inv_logit(X_psi * beta));
}
