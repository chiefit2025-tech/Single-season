# run_all.R --------------------------------------------------------------
# Runs the main analysis end to end (scripts 01-03).
# Script 04 (simulation study) is slower; run it separately if wanted.
source("R/01_simulate_data.R")
source("R/02_fit_models.R")
source("R/03_check_results.R")
