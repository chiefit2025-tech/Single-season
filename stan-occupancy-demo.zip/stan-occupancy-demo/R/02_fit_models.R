# 02_fit_models.R --------------------------------------------------------
# Fits the occupancy model and the naive logistic model with CmdStanR.

source("R/00_setup.R")
sim <- readRDS("data/sim_data.rds")

occ_mod   <- cmdstan_model("stan/occupancy.stan")
naive_mod <- cmdstan_model("stan/naive_logistic.stan")

fit_occ <- occ_mod$sample(
  data = sim$stan_data, seed = 123,
  chains = 4, parallel_chains = 4,
  iter_warmup = 1000, iter_sampling = 1000, refresh = 0
)

naive_data <- with(sim$stan_data, list(
  M = M, K_psi = K_psi, X_psi = X_psi,
  y_any = as.integer(rowSums(y) > 0)
))
fit_naive <- naive_mod$sample(
  data = naive_data, seed = 123,
  chains = 4, parallel_chains = 4, refresh = 0
)

# Convergence diagnostics (divergences, tree depth, E-BFMI)
print(fit_occ$diagnostic_summary())

fit_occ$save_object("output/fit_occupancy.rds")
fit_naive$save_object("output/fit_naive.rds")

print(fit_occ$summary(c("beta", "alpha", "psi_fs", "mean_p")))
print(fit_naive$summary(c("beta", "psi_naive")))
