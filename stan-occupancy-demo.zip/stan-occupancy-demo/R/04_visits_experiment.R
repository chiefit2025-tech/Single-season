# 04_visits_experiment.R -------------------------------------------------
# A small simulation study on data needs: how do bias and uncertainty in
# the estimated proportion of occupied sites change with the number of
# sites and the number of visits per site?
# Runtime: a few minutes (reduce n_rep for a quicker run).

source("R/00_setup.R")
source_lines <- readLines("R/01_simulate_data.R")
# Re-use simulate_occupancy() without re-running the rest of script 01
eval(parse(text = source_lines[grep("^simulate_occupancy <-", source_lines):
                               (grep("^sim <- simulate_occupancy", source_lines) - 1)]))

occ_mod <- cmdstan_model("stan/occupancy.stan")

scenarios <- expand.grid(M = c(100, 300),
                         visits = c("1-2 visits", "1-4 visits", "4 visits"),
                         stringsAsFactors = FALSE)
visit_probs <- list("1-2 visits" = c(0.5, 0.5, 0, 0),
                    "1-4 visits" = c(0.25, 0.25, 0.25, 0.25),
                    "4 visits"   = c(0, 0, 0, 1))
n_rep <- 10

results <- list()
for (s in seq_len(nrow(scenarios))) {
  for (r in seq_len(n_rep)) {
    sim <- simulate_occupancy(M = scenarios$M[s],
                              visit_probs = visit_probs[[scenarios$visits[s]]],
                              seed = 1000 * s + r)
    fit <- occ_mod$sample(data = sim$stan_data, seed = r, chains = 2,
                          iter_warmup = 500, iter_sampling = 500,
                          refresh = 0, show_messages = FALSE)
    d <- as.vector(fit$draws("psi_fs", format = "matrix"))
    q <- quantile(d, c(0.05, 0.95))
    results[[length(results) + 1]] <- data.frame(
      M = scenarios$M[s], visits = scenarios$visits[s], rep = r,
      error = mean(d) - sim$truth$psi_fs, width90 = q[2] - q[1],
      covered = sim$truth$psi_fs >= q[1] & sim$truth$psi_fs <= q[2])
  }
  cat("Finished scenario", s, "of", nrow(scenarios), "\n")
}
res <- do.call(rbind, results)

summary_tab <- aggregate(cbind(error, width90, covered) ~ M + visits, data = res, FUN = mean)
names(summary_tab) <- c("sites", "visits", "mean_error", "mean_90pct_width", "coverage")
summary_tab[, 3:5] <- round(summary_tab[, 3:5], 3)
print(summary_tab, row.names = FALSE)
write.csv(summary_tab, "output/visits_experiment.csv", row.names = FALSE)
