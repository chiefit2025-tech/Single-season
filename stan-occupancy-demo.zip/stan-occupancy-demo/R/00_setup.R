# 00_setup.R -------------------------------------------------------------
# Loads packages and checks that the script is run from the project root.
# One-time installation (outside this script):
#   install.packages("cmdstanr", repos = c("https://stan-dev.r-universe.dev",
#                                          getOption("repos")))
#   install.packages("posterior")
#   cmdstanr::install_cmdstan()

suppressPackageStartupMessages({
  library(cmdstanr)
  library(posterior)
})

if (!file.exists("stan/occupancy.stan")) {
  stop("Please set the working directory to the project root ",
       "(the folder that contains 'stan/' and 'R/').")
}

dir.create("data", showWarnings = FALSE)
dir.create("output/figures", recursive = TRUE, showWarnings = FALSE)

logit     <- function(p) log(p / (1 - p))
inv_logit <- function(x) 1 / (1 + exp(-x))
