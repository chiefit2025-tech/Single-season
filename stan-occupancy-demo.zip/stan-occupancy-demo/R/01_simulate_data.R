# 01_simulate_data.R -----------------------------------------------------
# Simulates detection/non-detection data from a single-season occupancy
# model with an unequal number of visits per site, loosely mimicking
# opportunistically collected citizen-science records.
#
# Scenario: a species that prefers forest (occupancy increases with forest
# cover) but is HARDER to detect in dense forest (detection decreases with
# forest cover). Detection also increases with observer effort on a visit.

source("R/00_setup.R")

simulate_occupancy <- function(M = 200, J = 4,
                               beta  = c(0.3, 1.0),        # psi: intercept, forest
                               alpha = c(-0.5, -0.7, 0.8), # p: intercept, forest, effort
                               visit_probs = c(0.25, 0.25, 0.25, 0.25),
                               seed = NULL) {
  if (!is.null(seed)) set.seed(seed)

  forest   <- as.numeric(scale(rnorm(M)))           # standardised site covariate
  n_visits <- sample(seq_len(J), M, replace = TRUE, prob = visit_probs)
  effort   <- matrix(rnorm(M * J), M, J)            # standardised visit covariate

  X_psi <- cbind(1, forest)
  psi   <- inv_logit(drop(X_psi %*% beta))
  z     <- rbinom(M, 1, psi)                        # true (latent) occupancy

  y   <- matrix(0L, M, J)
  X_p <- array(0, dim = c(M, J, length(alpha)))
  for (i in seq_len(M)) {
    X_p[i, , 1] <- 1
    X_p[i, , 2] <- forest[i]
    X_p[i, , 3] <- effort[i, ]
    p_i <- inv_logit(X_p[i, , ] %*% alpha)
    for (j in seq_len(n_visits[i])) {
      y[i, j] <- rbinom(1, 1, z[i] * p_i[j])
    }
  }

  list(
    stan_data = list(M = M, J = J, n_visits = n_visits, y = y,
                     K_psi = ncol(X_psi), X_psi = X_psi,
                     K_p = length(alpha), X_p = X_p),
    truth = list(beta = beta, alpha = alpha, z = z, psi = psi,
                 psi_fs = mean(z)),
    covariates = data.frame(site = seq_len(M), forest = forest,
                            n_visits = n_visits, z_true = z,
                            detected_any = as.integer(rowSums(y) > 0))
  )
}

sim <- simulate_occupancy(seed = 2026)
saveRDS(sim, "data/sim_data.rds")
write.csv(sim$covariates, "data/sites.csv", row.names = FALSE)

cat("Simulated", sim$stan_data$M, "sites\n")
cat("  True proportion occupied:          ", round(sim$truth$psi_fs, 3), "\n")
cat("  Proportion with >= 1 detection:    ",
    round(mean(sim$covariates$detected_any), 3), "\n")
cat("  Occupied but never detected (sites):",
    sum(sim$truth$z == 1 & sim$covariates$detected_any == 0), "\n")
